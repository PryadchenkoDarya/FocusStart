//
//  HistoryCurrencyView.m
//  Converter
//
//  Created by Student on 26.11.16.
//  Copyright © 2016 CFT. All rights reserved.
//

#import "HistoryCurrencyView.h"
#import "ViewController.h"

@implementation HistoryCurrencyView
{
    IBOutlet UITableView * TableData;
}

- ( void )viewDidLoad
{
//    [ super viewDidLoad ];
    // Do any additional setup after loading the view from its nib.
    self.title = @"History Currency";
//    CurrencyManager * CManager = [ [ CurrencyManager alloc ] init ];
//    CurrencyDS = [ [ CurrencyDatasource alloc ] initWithCurrencyManager:CManager ];
//    TableCurrency.dataSource = CurrencyDS;
//    TableCurrency.delegate = CurrencyDS;
//    [self configureNavigateItem];
}

@end
