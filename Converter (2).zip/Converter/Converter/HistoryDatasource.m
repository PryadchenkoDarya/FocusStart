//
//  HistoryDatasource.m
//  Converter
//
//  Created by Student on 05.12.16.
//  Copyright © 2016 CFT. All rights reserved.
//

#import "HistoryDatasource.h"
#import "HistoryViewController.h"
#import "HistoryCurrencyManager.h"

static NSString * const REUSE_IDENTIFIER = @"historyCell";

@implementation HistoryDatasource
{
    HistoryCurrencyManager * historyManager;
}

-( instancetype )initWithHistoryCurrencyManager:( HistoryCurrencyManager * )aHistoryManager
{
    self = [ super init ];
    historyManager = aHistoryManager;
    return self;
}

-( NSInteger )tableView:( UITableView * )tableView numberOfRowsInSection:( NSInteger) section
{
    return historyManager.dates.count;
}

-( UITableViewCell * )tableView:( UITableView * )tableView cellForRowAtIndexPath:( NSIndexPath * )indexPath
{
    UITableViewCell * cell = [ tableView dequeueReusableCellWithIdentifier:REUSE_IDENTIFIER ];
    
    if( nil == cell )
    {
        cell = [ [ UITableViewCell alloc ] initWithStyle: UITableViewCellStyleSubtitle reuseIdentifier:REUSE_IDENTIFIER ];
    }
    
    cell.textLabel.text = historyManager.dates[ indexPath.row ];
    cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    
    return cell;
}

-( void )tableView:( UITableView * )tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    _selectedDate = historyManager.dates[ indexPath.row ];
}

-( instancetype )init
{
    assert( NO );
    return nil;
}
@end
