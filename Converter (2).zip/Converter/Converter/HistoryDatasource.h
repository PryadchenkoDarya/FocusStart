//
//  HistoryDatasource.h
//  Converter
//
//  Created by Student on 05.12.16.
//  Copyright © 2016 CFT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include "HistoryCurrencyManager.h"

@interface HistoryDatasource : NSObject< UITableViewDataSource, UITableViewDelegate  >

@property( nonatomic ) NSString * selectedDate;

-( instancetype )initWithHistoryCurrencyManager:(HistoryCurrencyManager *) aCurrencyManager;
-( instancetype )init NS_UNAVAILABLE;

@end
