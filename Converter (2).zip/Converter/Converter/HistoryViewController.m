//
//  HistoryViewController.m
//  Converter
//
//  Created by Student on 26.11.16.
//  Copyright © 2016 CFT. All rights reserved.
//

#import "HistoryViewController.h"
#import "HistoryCurrencyManager.h"
#import "HistoryDatasource.h"
#import "ViewController.h"
#import "CurrencyManager.h"

static NSString * const REUSE_IDENTIFIER = @"historyCell";

@interface HistoryViewController () < UITableViewDelegate >

@end

@implementation HistoryViewController
{
    IBOutlet UITableView * TableDates;
    HistoryDatasource * HistoryDS;
    HistoryCurrencyManager *hManager;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"History";
    hManager = [ [ HistoryCurrencyManager alloc ] init ];
    HistoryDS = [ [ HistoryDatasource alloc ] initWithHistoryCurrencyManager:hManager ];
    TableDates.dataSource = HistoryDS;
    TableDates.delegate = HistoryDS;
    _appContext = [ [ AppContext alloc ] initWithConfigName:@"config.plist" ];
    [self configureNavigateItem];
}

-( void )tableView:( UITableView * ) tableView accessoryButtonTappedForRowWithIndexPath:( NSIndexPath * )indexPath
{
    [ HistoryDS tableView: TableDates didSelectRowAtIndexPath:indexPath ];
    
    typeof ( self ) __weak weakSelf = self;
    [ self.appContext.exchangeRatesManager exchangeHistory:HistoryDS.selectedDate completion:^( NSMutableArray * dates)
    {
        [ weakSelf updateDate:dates];
    } ];
}
-( void ) updateDate:( NSMutableArray *) rate
{
    CurrencyManager * manager = [ [ CurrencyManager alloc ] init ];
    NSString * baseCurrency = manager.baseCurrency.code;
    NSString * info = @"";
    int i = 0;
    if( ! [ baseCurrency isEqualToString:@"RUB" ] )
    {
        info = [ NSString stringWithFormat:@"%@%@%@", info, @" RUB ", [ rate objectAtIndex : i ] ];
        ++i;
    }
    if( ! [ baseCurrency isEqualToString:@"USD" ] )
    {
        info = [ NSString stringWithFormat:@"%@%@%@", info, @" USD ", [ rate objectAtIndex : i ] ];
        ++i;
    }
    if( ! [ baseCurrency isEqualToString:@"GBP" ] )
    {
        info = [ NSString stringWithFormat:@"%@%@%@", info, @" GBP ", [ rate objectAtIndex : i ] ];
        ++i;
    }
    if( ! [ baseCurrency isEqualToString:@"AUD" ] )
    {
        info = [ NSString stringWithFormat:@"%@%@%@", info, @" AUD ", [ rate objectAtIndex : i ] ];
        ++i;
    }    UIAlertController * alert = [ UIAlertController alertControllerWithTitle: HistoryDS.selectedDate massage: info preferredStyle: UIAlertControllerStyleAlert ];
    UIAlertAction *action = [ UIAlertAction actionWithTitle: @"Close" style: UIAlertActionStyleCancel handler: nil ];
    [ alert addAction : actionCancel ];
    [ self presentViewController: alert animated: YES completion : nil ];
}
-( void )configureNavigateItem
{
    UIBarButtonItem *doneButton=[ [ UIBarButtonItem alloc ] initWithTitle: @"Back" style:UIBarButtonItemStyleDone target:self action:@selector( doneTapped ) ];
    self.navigationItem.rightBarButtonItem = doneButton;
}

-( void )doneTapped
{
    [ self.delegate HistoryDS ];
}

-(void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-( void )tableView:( UITableView * )tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    HistoryDS.selectedDate = hManager.dates[ indexPath.row ];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
