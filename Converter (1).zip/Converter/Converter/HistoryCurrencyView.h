//
//  HistoryCurrencyView.h
//  Converter
//
//  Created by Student on 26.11.16.
//  Copyright © 2016 CFT. All rights reserved.
//

//#import <Foundation/Foundation.h>
#import "<UIKit/UIKit.h>"
#import "CurrencyViewControllerDelegate.h"

@interface HistoryCurrencyView : NSObject  : UIViewController<CurrencyViewControllerDelegate>

@property( nonatomic, readonly ) 

@end
