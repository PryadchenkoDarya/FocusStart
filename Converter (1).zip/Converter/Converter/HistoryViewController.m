//
//  HistoryViewController.m
//  Converter
//
//  Created by Student on 26.11.16.
//  Copyright © 2016 CFT. All rights reserved.
//

#import "HistoryViewController.h"
#import "HistoryCurrencyManager.h"
#import "HistoryDatasource.h"
#import "ViewController.h"

static NSString * const REUSE_IDENTIFIER = @"historyCell";

@interface HistoryViewController ()

@end

@implementation HistoryViewController
{
    IBOutlet UITableView * TableDates;
    HistoryDatasource * HistoryDS;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"History";
    HistoryCurrencyManager * hManager = [ [ HistoryCurrencyManager alloc ] init ];
    HistoryDS = [ [ HistoryDatasource alloc ] initWithHistoryCurrencyManager:hManager ];
    TableDates.dataSource = HistoryDS;
    TableDates.delegate = HistoryDS;
    [self configureNavigateItem];
}

-( void )configureNavigateItem
{
    UIBarButtonItem *doneButton=[ [ UIBarButtonItem alloc ] initWithTitle: @"Back" style:UIBarButtonItemStyleDone target:self action:@selector( doneTapped ) ];
    self.navigationItem.rightBarButtonItem = doneButton;
}

-( void )doneTapped
{
    [ HistoryDS tableView:TableDates didSelectRowAtIndexPath:TableDates.indexPathForSelectedRow];
   // [ self.delegate HistoryDS ];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
