//
//  CurrencyManager.m
//  Converter
//
//  Created by Student on 12.11.16.
//  Copyright © 2016 CFT. All rights reserved.
//

#import "CurrencyManager.h"
#import "Currency.h"


@implementation CurrencyManager


-( Currency * )baseCurrency
{
    NSString *localConfigPath = [[NSBundle mainBundle] pathForResource:@"config.plist".stringByDeletingPathExtension
                                                                ofType:@"config.plist".pathExtension];
    
    NSDictionary *contents = [NSDictionary dictionaryWithContentsOfFile:localConfigPath];
    return [Currency currencyWithCode:contents[NSStringFromSelector(@selector(codeBaseCurrency))] name:contents[NSStringFromSelector(@selector(currencyName))]];
}


-( instancetype )init
{
    self = [ super init ];
    
    NSMutableArray *currencies = [ [ NSMutableArray alloc ] init ] ;
    
    Currency * currency = [ self baseCurrency ];
    
    if( ![ currency.code  isEqualToString: @"USD" ] )
    {
        [ currencies addObject:[ Currency currencyWithCode:@"USD" name:@"American dollar" ] ];
    }
    if( ![ currency.code  isEqualToString: @"AUD" ] )
    {
        [ currencies addObject:[ Currency currencyWithCode:@"AUD" name:@"Australian dollar" ] ];
    }
    if( ![ currency.code isEqualToString: @"RUB" ] )
    {
        [ currencies addObject:[ Currency currencyWithCode:@"RUB" name:@"Russian ruble" ] ];
    }
    if( ![ currency.code isEqualToString: @"GBP" ] )
    {
        [ currencies addObject:[ Currency currencyWithCode:@"GBP" name:@"Pound sterling" ] ];
    }
    
    _currencies = [ currencies copy ];
    
    return self;
}

-( Currency * )defaultCurrency
{
    return _currencies.firstObject;
}


@end
