//
//  HistoryCurrencyManager.m
//  Converter
//
//  Created by Student on 26.11.16.
//  Copyright © 2016 CFT. All rights reserved.
//

#import "HistoryCurrencyManager.h"

@implementation HistoryCurrencyManager

-( instancetype )init
{
    self = [ super init ];
    NSDate *currentDate = [NSDate date];
    NSMutableArray *dates = [ [ NSMutableArray alloc ] init ] ;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    
    for( int i = 0; i < 21; ++i )
    {
        NSDate * date = [ currentDate dateByAddingTimeInterval:-(60*60*24*i) ];
        [ dates addObject:[ dateFormatter stringFromDate:date ] ];
    }
    
    _dates = [dates copy ];
    
    return self;
}

@end
